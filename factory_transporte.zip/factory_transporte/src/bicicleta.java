// Clase Bicicleta que hereda de Transporte
class Bicicleta extends Transporte {
    @Override
    float costeTotal(int cp) {
        // Cálculo del coste para la bicicleta (solo para fines de demostración)
        // Aquí se puede implementar la lógica real para calcular el coste total según el código postal
        return 10.0f;
    }

    @Override
    int tipoEmbalaje(float x, float y, float z, float peso) {
        // Lógica para determinar el tipo de embalaje para la bicicleta (solo para fines de demostración)
        // En este caso, asumimos que siempre se utiliza envoltorio de cartón
        return 1; // envoltorio cartón
    }
}

