// Clase abstracta Transporte
abstract class Transporte {
    abstract float costeTotal(int cp);
    abstract int tipoEmbalaje(float x, float y, float z, float peso);
}

// Clase Camión que hereda de Transporte
class Camion extends Transporte {
    @Override
    float costeTotal(int cp) {
        // Cálculo del coste para el camión (solo para fines de demostración)
        // Aquí se puede implementar la lógica real para calcular el coste total según el código postal
        return 50.0f;
    }

    @Override
    int tipoEmbalaje(float x, float y, float z, float peso) {
        // Lógica para determinar el tipo de embalaje para el camión (solo para fines de demostración)
        // Aquí se puede implementar la lógica real para determinar el tipo de embalaje según las dimensiones y el peso
        if (peso > 100) {
            return 0; // palet
        } else if (x > 10 && y > 10 && z > 10) {
            return 2; // caja de madera
        } else {
            return 1; // envoltorio cartón
        }
    }
}
