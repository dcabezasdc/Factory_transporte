// Clase principal para probar la aplicación
public class Main {
    public static void main(String[] args) {
        // Instanciando un camión
        Camion camion = new Camion();
        int codigoPostal = 12345;
        System.out.println("Coste total para el camión: $" + camion.costeTotal(codigoPostal));
        System.out.println("Tipo de embalaje para el camión: " + camion.tipoEmbalaje(20, 20, 20, 150));

        // Instanciando una bicicleta
        Bicicleta bicicleta = new Bicicleta();
        System.out.println("Coste total para la bicicleta: $" + bicicleta.costeTotal(codigoPostal));
        System.out.println("Tipo de embalaje para la bicicleta: " + bicicleta.tipoEmbalaje(10, 5, 5, 10));
    }
}
